# Yolo-Nas_Obect_detection
This is Yolo-Nas object detection on custom dataset
![Efficient-Frontier-of-Object-Detection-on-COCO-Measured-on-NVIDIA-T4_1](https://github.com/IIskel/Yolo-Nas_Obect_detection/assets/106806690/a4bf71b9-5b64-473b-b2b9-909c49089308)
